window.location.href = 'https://wolkanca.com/etiket/serp-counter/'
